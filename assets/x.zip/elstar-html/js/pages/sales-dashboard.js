/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/picocolors/picocolors.browser.js":
/*!*******************************************************!*\
  !*** ./node_modules/picocolors/picocolors.browser.js ***!
  \*******************************************************/
/***/ ((module) => {

eval("var x=String;\nvar create=function() {return {isColorSupported:false,reset:x,bold:x,dim:x,italic:x,underline:x,inverse:x,hidden:x,strikethrough:x,black:x,red:x,green:x,yellow:x,blue:x,magenta:x,cyan:x,white:x,gray:x,bgBlack:x,bgRed:x,bgGreen:x,bgYellow:x,bgBlue:x,bgMagenta:x,bgCyan:x,bgWhite:x}};\nmodule.exports=create();\nmodule.exports.createColors = create;\n\n\n//# sourceURL=webpack://elstar/./node_modules/picocolors/picocolors.browser.js?");

/***/ }),

/***/ "./node_modules/tailwindcss/colors.js":
/*!********************************************!*\
  !*** ./node_modules/tailwindcss/colors.js ***!
  \********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("let colors = __webpack_require__(/*! ./lib/public/colors */ \"./node_modules/tailwindcss/lib/public/colors.js\")\nmodule.exports = (colors.__esModule ? colors : { default: colors }).default\n\n\n//# sourceURL=webpack://elstar/./node_modules/tailwindcss/colors.js?");

/***/ }),

/***/ "./node_modules/tailwindcss/lib/public/colors.js":
/*!*******************************************************!*\
  !*** ./node_modules/tailwindcss/lib/public/colors.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
eval("\nObject.defineProperty(exports, \"__esModule\", ({\n    value: true\n}));\nObject.defineProperty(exports, \"default\", ({\n    enumerable: true,\n    get: ()=>_default\n}));\nconst _log = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(/*! ../util/log */ \"./node_modules/tailwindcss/lib/util/log.js\"));\nfunction _interopRequireDefault(obj) {\n    return obj && obj.__esModule ? obj : {\n        default: obj\n    };\n}\nfunction warn({ version , from , to  }) {\n    _log.default.warn(`${from}-color-renamed`, [\n        `As of Tailwind CSS ${version}, \\`${from}\\` has been renamed to \\`${to}\\`.`,\n        \"Update your configuration file to silence this warning.\"\n    ]);\n}\nconst _default = {\n    inherit: \"inherit\",\n    current: \"currentColor\",\n    transparent: \"transparent\",\n    black: \"#000\",\n    white: \"#fff\",\n    slate: {\n        50: \"#f8fafc\",\n        100: \"#f1f5f9\",\n        200: \"#e2e8f0\",\n        300: \"#cbd5e1\",\n        400: \"#94a3b8\",\n        500: \"#64748b\",\n        600: \"#475569\",\n        700: \"#334155\",\n        800: \"#1e293b\",\n        900: \"#0f172a\",\n        950: \"#020617\"\n    },\n    gray: {\n        50: \"#f9fafb\",\n        100: \"#f3f4f6\",\n        200: \"#e5e7eb\",\n        300: \"#d1d5db\",\n        400: \"#9ca3af\",\n        500: \"#6b7280\",\n        600: \"#4b5563\",\n        700: \"#374151\",\n        800: \"#1f2937\",\n        900: \"#111827\",\n        950: \"#030712\"\n    },\n    zinc: {\n        50: \"#fafafa\",\n        100: \"#f4f4f5\",\n        200: \"#e4e4e7\",\n        300: \"#d4d4d8\",\n        400: \"#a1a1aa\",\n        500: \"#71717a\",\n        600: \"#52525b\",\n        700: \"#3f3f46\",\n        800: \"#27272a\",\n        900: \"#18181b\",\n        950: \"#09090b\"\n    },\n    neutral: {\n        50: \"#fafafa\",\n        100: \"#f5f5f5\",\n        200: \"#e5e5e5\",\n        300: \"#d4d4d4\",\n        400: \"#a3a3a3\",\n        500: \"#737373\",\n        600: \"#525252\",\n        700: \"#404040\",\n        800: \"#262626\",\n        900: \"#171717\",\n        950: \"#0a0a0a\"\n    },\n    stone: {\n        50: \"#fafaf9\",\n        100: \"#f5f5f4\",\n        200: \"#e7e5e4\",\n        300: \"#d6d3d1\",\n        400: \"#a8a29e\",\n        500: \"#78716c\",\n        600: \"#57534e\",\n        700: \"#44403c\",\n        800: \"#292524\",\n        900: \"#1c1917\",\n        950: \"#0c0a09\"\n    },\n    red: {\n        50: \"#fef2f2\",\n        100: \"#fee2e2\",\n        200: \"#fecaca\",\n        300: \"#fca5a5\",\n        400: \"#f87171\",\n        500: \"#ef4444\",\n        600: \"#dc2626\",\n        700: \"#b91c1c\",\n        800: \"#991b1b\",\n        900: \"#7f1d1d\",\n        950: \"#450a0a\"\n    },\n    orange: {\n        50: \"#fff7ed\",\n        100: \"#ffedd5\",\n        200: \"#fed7aa\",\n        300: \"#fdba74\",\n        400: \"#fb923c\",\n        500: \"#f97316\",\n        600: \"#ea580c\",\n        700: \"#c2410c\",\n        800: \"#9a3412\",\n        900: \"#7c2d12\",\n        950: \"#431407\"\n    },\n    amber: {\n        50: \"#fffbeb\",\n        100: \"#fef3c7\",\n        200: \"#fde68a\",\n        300: \"#fcd34d\",\n        400: \"#fbbf24\",\n        500: \"#f59e0b\",\n        600: \"#d97706\",\n        700: \"#b45309\",\n        800: \"#92400e\",\n        900: \"#78350f\",\n        950: \"#451a03\"\n    },\n    yellow: {\n        50: \"#fefce8\",\n        100: \"#fef9c3\",\n        200: \"#fef08a\",\n        300: \"#fde047\",\n        400: \"#facc15\",\n        500: \"#eab308\",\n        600: \"#ca8a04\",\n        700: \"#a16207\",\n        800: \"#854d0e\",\n        900: \"#713f12\",\n        950: \"#422006\"\n    },\n    lime: {\n        50: \"#f7fee7\",\n        100: \"#ecfccb\",\n        200: \"#d9f99d\",\n        300: \"#bef264\",\n        400: \"#a3e635\",\n        500: \"#84cc16\",\n        600: \"#65a30d\",\n        700: \"#4d7c0f\",\n        800: \"#3f6212\",\n        900: \"#365314\",\n        950: \"#1a2e05\"\n    },\n    green: {\n        50: \"#f0fdf4\",\n        100: \"#dcfce7\",\n        200: \"#bbf7d0\",\n        300: \"#86efac\",\n        400: \"#4ade80\",\n        500: \"#22c55e\",\n        600: \"#16a34a\",\n        700: \"#15803d\",\n        800: \"#166534\",\n        900: \"#14532d\",\n        950: \"#052e16\"\n    },\n    emerald: {\n        50: \"#ecfdf5\",\n        100: \"#d1fae5\",\n        200: \"#a7f3d0\",\n        300: \"#6ee7b7\",\n        400: \"#34d399\",\n        500: \"#10b981\",\n        600: \"#059669\",\n        700: \"#047857\",\n        800: \"#065f46\",\n        900: \"#064e3b\",\n        950: \"#022c22\"\n    },\n    teal: {\n        50: \"#f0fdfa\",\n        100: \"#ccfbf1\",\n        200: \"#99f6e4\",\n        300: \"#5eead4\",\n        400: \"#2dd4bf\",\n        500: \"#14b8a6\",\n        600: \"#0d9488\",\n        700: \"#0f766e\",\n        800: \"#115e59\",\n        900: \"#134e4a\",\n        950: \"#042f2e\"\n    },\n    cyan: {\n        50: \"#ecfeff\",\n        100: \"#cffafe\",\n        200: \"#a5f3fc\",\n        300: \"#67e8f9\",\n        400: \"#22d3ee\",\n        500: \"#06b6d4\",\n        600: \"#0891b2\",\n        700: \"#0e7490\",\n        800: \"#155e75\",\n        900: \"#164e63\",\n        950: \"#083344\"\n    },\n    sky: {\n        50: \"#f0f9ff\",\n        100: \"#e0f2fe\",\n        200: \"#bae6fd\",\n        300: \"#7dd3fc\",\n        400: \"#38bdf8\",\n        500: \"#0ea5e9\",\n        600: \"#0284c7\",\n        700: \"#0369a1\",\n        800: \"#075985\",\n        900: \"#0c4a6e\",\n        950: \"#082f49\"\n    },\n    blue: {\n        50: \"#eff6ff\",\n        100: \"#dbeafe\",\n        200: \"#bfdbfe\",\n        300: \"#93c5fd\",\n        400: \"#60a5fa\",\n        500: \"#3b82f6\",\n        600: \"#2563eb\",\n        700: \"#1d4ed8\",\n        800: \"#1e40af\",\n        900: \"#1e3a8a\",\n        950: \"#172554\"\n    },\n    indigo: {\n        50: \"#eef2ff\",\n        100: \"#e0e7ff\",\n        200: \"#c7d2fe\",\n        300: \"#a5b4fc\",\n        400: \"#818cf8\",\n        500: \"#6366f1\",\n        600: \"#4f46e5\",\n        700: \"#4338ca\",\n        800: \"#3730a3\",\n        900: \"#312e81\",\n        950: \"#1e1b4b\"\n    },\n    violet: {\n        50: \"#f5f3ff\",\n        100: \"#ede9fe\",\n        200: \"#ddd6fe\",\n        300: \"#c4b5fd\",\n        400: \"#a78bfa\",\n        500: \"#8b5cf6\",\n        600: \"#7c3aed\",\n        700: \"#6d28d9\",\n        800: \"#5b21b6\",\n        900: \"#4c1d95\",\n        950: \"#2e1065\"\n    },\n    purple: {\n        50: \"#faf5ff\",\n        100: \"#f3e8ff\",\n        200: \"#e9d5ff\",\n        300: \"#d8b4fe\",\n        400: \"#c084fc\",\n        500: \"#a855f7\",\n        600: \"#9333ea\",\n        700: \"#7e22ce\",\n        800: \"#6b21a8\",\n        900: \"#581c87\",\n        950: \"#3b0764\"\n    },\n    fuchsia: {\n        50: \"#fdf4ff\",\n        100: \"#fae8ff\",\n        200: \"#f5d0fe\",\n        300: \"#f0abfc\",\n        400: \"#e879f9\",\n        500: \"#d946ef\",\n        600: \"#c026d3\",\n        700: \"#a21caf\",\n        800: \"#86198f\",\n        900: \"#701a75\",\n        950: \"#4a044e\"\n    },\n    pink: {\n        50: \"#fdf2f8\",\n        100: \"#fce7f3\",\n        200: \"#fbcfe8\",\n        300: \"#f9a8d4\",\n        400: \"#f472b6\",\n        500: \"#ec4899\",\n        600: \"#db2777\",\n        700: \"#be185d\",\n        800: \"#9d174d\",\n        900: \"#831843\",\n        950: \"#500724\"\n    },\n    rose: {\n        50: \"#fff1f2\",\n        100: \"#ffe4e6\",\n        200: \"#fecdd3\",\n        300: \"#fda4af\",\n        400: \"#fb7185\",\n        500: \"#f43f5e\",\n        600: \"#e11d48\",\n        700: \"#be123c\",\n        800: \"#9f1239\",\n        900: \"#881337\",\n        950: \"#4c0519\"\n    },\n    get lightBlue () {\n        warn({\n            version: \"v2.2\",\n            from: \"lightBlue\",\n            to: \"sky\"\n        });\n        return this.sky;\n    },\n    get warmGray () {\n        warn({\n            version: \"v3.0\",\n            from: \"warmGray\",\n            to: \"stone\"\n        });\n        return this.stone;\n    },\n    get trueGray () {\n        warn({\n            version: \"v3.0\",\n            from: \"trueGray\",\n            to: \"neutral\"\n        });\n        return this.neutral;\n    },\n    get coolGray () {\n        warn({\n            version: \"v3.0\",\n            from: \"coolGray\",\n            to: \"gray\"\n        });\n        return this.gray;\n    },\n    get blueGray () {\n        warn({\n            version: \"v3.0\",\n            from: \"blueGray\",\n            to: \"slate\"\n        });\n        return this.slate;\n    }\n};\n\n\n//# sourceURL=webpack://elstar/./node_modules/tailwindcss/lib/public/colors.js?");

/***/ }),

/***/ "./node_modules/tailwindcss/lib/util/log.js":
/*!**************************************************!*\
  !*** ./node_modules/tailwindcss/lib/util/log.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
eval("\nObject.defineProperty(exports, \"__esModule\", ({\n    value: true\n}));\nfunction _export(target, all) {\n    for(var name in all)Object.defineProperty(target, name, {\n        enumerable: true,\n        get: all[name]\n    });\n}\n_export(exports, {\n    dim: ()=>dim,\n    default: ()=>_default\n});\nconst _picocolors = /*#__PURE__*/ _interopRequireDefault(__webpack_require__(/*! picocolors */ \"./node_modules/picocolors/picocolors.browser.js\"));\nfunction _interopRequireDefault(obj) {\n    return obj && obj.__esModule ? obj : {\n        default: obj\n    };\n}\nlet alreadyShown = new Set();\nfunction log(type, messages, key) {\n    if (typeof process !== \"undefined\" && process.env.JEST_WORKER_ID) return;\n    if (key && alreadyShown.has(key)) return;\n    if (key) alreadyShown.add(key);\n    console.warn(\"\");\n    messages.forEach((message)=>console.warn(type, \"-\", message));\n}\nfunction dim(input) {\n    return _picocolors.default.dim(input);\n}\nconst _default = {\n    info (key, messages) {\n        log(_picocolors.default.bold(_picocolors.default.cyan(\"info\")), ...Array.isArray(key) ? [\n            key\n        ] : [\n            messages,\n            key\n        ]);\n    },\n    warn (key, messages) {\n        log(_picocolors.default.bold(_picocolors.default.yellow(\"warn\")), ...Array.isArray(key) ? [\n            key\n        ] : [\n            messages,\n            key\n        ]);\n    },\n    risk (key, messages) {\n        log(_picocolors.default.bold(_picocolors.default.magenta(\"risk\")), ...Array.isArray(key) ? [\n            key\n        ] : [\n            messages,\n            key\n        ]);\n    }\n};\n\n\n//# sourceURL=webpack://elstar/./node_modules/tailwindcss/lib/util/log.js?");

/***/ }),

/***/ "./src/es/constant/chart.constant.js":
/*!*******************************************!*\
  !*** ./src/es/constant/chart.constant.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ApexBarDefault: () => (/* binding */ ApexBarDefault),\n/* harmony export */   ApexChartDefault: () => (/* binding */ ApexChartDefault),\n/* harmony export */   ApexColorDefault: () => (/* binding */ ApexColorDefault),\n/* harmony export */   ApexDataLabelDefault: () => (/* binding */ ApexDataLabelDefault),\n/* harmony export */   ApexDonutChartDefault: () => (/* binding */ ApexDonutChartDefault),\n/* harmony export */   ApexLineChartDefault: () => (/* binding */ ApexLineChartDefault),\n/* harmony export */   ApexStrokeDefault: () => (/* binding */ ApexStrokeDefault),\n/* harmony export */   COLORS: () => (/* binding */ COLORS),\n/* harmony export */   COLORS_LIGHT: () => (/* binding */ COLORS_LIGHT),\n/* harmony export */   COLOR_1: () => (/* binding */ COLOR_1),\n/* harmony export */   COLOR_1_LIGHT: () => (/* binding */ COLOR_1_LIGHT),\n/* harmony export */   COLOR_2: () => (/* binding */ COLOR_2),\n/* harmony export */   COLOR_2_LIGHT: () => (/* binding */ COLOR_2_LIGHT),\n/* harmony export */   COLOR_3: () => (/* binding */ COLOR_3),\n/* harmony export */   COLOR_3_LIGHT: () => (/* binding */ COLOR_3_LIGHT),\n/* harmony export */   COLOR_4: () => (/* binding */ COLOR_4),\n/* harmony export */   COLOR_4_LIGHT: () => (/* binding */ COLOR_4_LIGHT),\n/* harmony export */   COLOR_5: () => (/* binding */ COLOR_5),\n/* harmony export */   COLOR_5_LIGHT: () => (/* binding */ COLOR_5_LIGHT),\n/* harmony export */   COLOR_6: () => (/* binding */ COLOR_6),\n/* harmony export */   COLOR_6_LIGHT: () => (/* binding */ COLOR_6_LIGHT),\n/* harmony export */   COLOR_7: () => (/* binding */ COLOR_7),\n/* harmony export */   COLOR_7_LIGHT: () => (/* binding */ COLOR_7_LIGHT)\n/* harmony export */ });\n/* harmony import */ var _theme_constant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./theme-constant */ \"./src/es/constant/theme-constant.js\");\n\r\n\r\nconst twColor = _theme_constant__WEBPACK_IMPORTED_MODULE_0__.themeColors\r\n\r\nconst COLOR_1 = twColor.indigo['600']\r\nconst COLOR_2 = twColor.blue['500']\r\nconst COLOR_3 = twColor.emerald['500']\r\nconst COLOR_4 = twColor.amber['500']\r\nconst COLOR_5 = twColor.red['500']\r\nconst COLOR_6 = twColor.purple['500']\r\nconst COLOR_7 = twColor.cyan['500']\r\n\r\nconst COLOR_1_LIGHT = twColor.indigo['100']\r\nconst COLOR_2_LIGHT = twColor.blue['100']\r\nconst COLOR_3_LIGHT = twColor.emerald['100']\r\nconst COLOR_4_LIGHT = twColor.amber['100']\r\nconst COLOR_5_LIGHT = twColor.red['100']\r\nconst COLOR_6_LIGHT = twColor.purple['100']\r\nconst COLOR_7_LIGHT = twColor.cyan['100']\r\n\r\nconst COLORS = [\r\n    COLOR_1,\r\n    COLOR_2,\r\n    COLOR_3,\r\n    COLOR_4,\r\n    COLOR_5,\r\n    COLOR_6,\r\n    COLOR_7,\r\n]\r\n\r\nconst COLORS_LIGHT = [\r\n    COLOR_1_LIGHT,\r\n    COLOR_2_LIGHT,\r\n    COLOR_3_LIGHT,\r\n    COLOR_4_LIGHT,\r\n    COLOR_5_LIGHT,\r\n    COLOR_6_LIGHT,\r\n    COLOR_7_LIGHT,\r\n]\r\n\r\n\r\nconst ApexChartDefault = {\r\n    type: 'line',\r\n    zoom: {\r\n        enabled: false\r\n    },\r\n    toolbar: {\r\n        show: false\r\n    }\r\n}\r\n\r\nconst ApexStrokeDefault = {\r\n    width: 3,\r\n    curve: \"smooth\",\r\n    lineCap: 'round'\r\n}\r\n\r\nconst ApexBarDefault = {\r\n\tchart: {\r\n        zoom: {\r\n            enabled: false,\r\n        },\r\n        toolbar: {\r\n            show: false,\r\n        },\r\n        type: \"bar\",\r\n        height: 300\r\n    },\r\n    plotOptions: {\r\n        bar: {\r\n            horizontal: false,\r\n            columnWidth: '30px',\r\n            borderRadius: 2,\r\n        },\r\n    },\r\n    colors: [...COLORS],\r\n    dataLabels: {\r\n        enabled: false,\r\n    },\r\n    stroke: {\r\n        show: true,\r\n        width: 6,\r\n        curve: 'smooth',\r\n        colors: ['transparent'],\r\n    },\r\n    legend: {\r\n        itemMargin: {\r\n            vertical: 10,\r\n        },\r\n        tooltipHoverFormatter: function (val, opts) {\r\n            return (\r\n                val +\r\n                ' - ' +\r\n                opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex] +\r\n                ''\r\n            )\r\n        },\r\n    },\r\n    xaxis: {\r\n        categories: [],\r\n    },\r\n    fill: {\r\n        opacity: 1,\r\n    },\r\n    tooltip: {\r\n        y: {\r\n            formatter: (val) => `${val}`,\r\n        },\r\n    },\r\n    \r\n}\r\n\r\nconst ApexDataLabelDefault = {\r\n    enabled: false\r\n}\r\n\r\nconst ApexDonutChartDefault = {\r\n    colors: [...COLORS],\r\n    plotOptions: {\r\n        pie: {\r\n            donut: {\r\n                labels: {\r\n                    show: true,\r\n                    total: {\r\n                        show: true,\r\n                        showAlways: true,\r\n                        label: '',\r\n                        formatter: function (w) {\r\n                            return w.globals.seriesTotals.reduce(\r\n                                (a, b) => {\r\n                                    return a + b\r\n                                },\r\n                                0\r\n                            )\r\n                        },\r\n                    },\r\n                },\r\n                size: '85%',\r\n            },\r\n        },\r\n    },\r\n    stroke: {\r\n        colors: ['transparent'],\r\n    },\r\n    labels: [],\r\n    dataLabels: {\r\n        enabled: false,\r\n    },\r\n    legend: {\r\n        show: false,\r\n    },\r\n}\r\n\r\nconst ApexLineChartDefault = {\r\n    chart: {\r\n        zoom: {\r\n            enabled: false,\r\n        },\r\n        toolbar: {\r\n            show: false,\r\n        },\r\n    },\r\n    colors: [...COLORS],\r\n    dataLabels: {\r\n        enabled: false,\r\n    },\r\n    stroke: {\r\n        width: 2.5,\r\n        curve: 'smooth',\r\n        lineCap: 'round',\r\n    },\r\n    legend: {\r\n        itemMargin: {\r\n            vertical: 10,\r\n        },\r\n        tooltipHoverFormatter: function (val, opts) {\r\n            return (\r\n                val +\r\n                ' - ' +\r\n                opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex] +\r\n                ''\r\n            )\r\n        },\r\n    },\r\n    xaxis: {\r\n        categories: [],\r\n    },\r\n}\r\n\r\nconst ApexColorDefault = [...COLORS]\n\n//# sourceURL=webpack://elstar/./src/es/constant/chart.constant.js?");

/***/ }),

/***/ "./src/es/constant/theme-constant.js":
/*!*******************************************!*\
  !*** ./src/es/constant/theme-constant.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   themeColors: () => (/* binding */ themeColors)\n/* harmony export */ });\n/* harmony import */ var tailwindcss_colors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tailwindcss/colors */ \"./node_modules/tailwindcss/colors.js\");\n/* harmony import */ var tailwindcss_colors__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tailwindcss_colors__WEBPACK_IMPORTED_MODULE_0__);\n\r\n\r\nconst themeColors = (tailwindcss_colors__WEBPACK_IMPORTED_MODULE_0___default())\r\n\n\n//# sourceURL=webpack://elstar/./src/es/constant/theme-constant.js?");

/***/ }),

/***/ "./src/es/pages/sales-dashboard.js":
/*!*****************************************!*\
  !*** ./src/es/pages/sales-dashboard.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constant/chart.constant */ \"./src/es/constant/chart.constant.js\");\n\r\n\r\n_constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__.ApexLineChartDefault.chart.height = \"380px\"\r\n\r\nconst salesReportChartOption = {\r\n    ..._constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__.ApexLineChartDefault,\r\n    series: [\r\n        {\r\n            name: 'Online Sales',\r\n            data: [24, 33, 29, 36, 34, 43, 40, 47, 45, 48, 46, 55],\r\n        },\r\n        {\r\n            name: 'Marketing Sales',\r\n            data: [20, 26, 23, 24, 22, 29, 27, 36, 32, 35, 32, 38],\r\n        },\r\n    ],\r\n    xaxis: {\r\n        categories: [\r\n            '01 Jan',\r\n            '02 Jan',\r\n            '03 Jan',\r\n            '04 Jan',\r\n            '05 Jan',\r\n            '06 Jan',\r\n            '07 Jan',\r\n            '08 Jan',\r\n            '09 Jan',\r\n            '10 Jan',\r\n            '11 Jan',\r\n            '12 Jan',\r\n        ]\r\n    },\r\n    legend: {\r\n        show: false\r\n    },\r\n}\r\nnew ApexCharts(document.querySelector(\"#sales-report-chart\"), salesReportChartOption).render();\r\n\r\n_constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__.ApexDonutChartDefault.plotOptions.pie.donut.labels.total.formatter = () => 'Product Sold'\r\n_constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__.ApexDonutChartDefault.plotOptions.pie.donut.labels.total.label = '284'\r\n\r\nconst categoriesChartOption ={\r\n    chart: {\r\n        ..._constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__.ApexChartDefault,\r\n        height: 300,\r\n        type: \"donut\"\r\n    },\r\n    ..._constant_chart_constant__WEBPACK_IMPORTED_MODULE_0__.ApexDonutChartDefault,\r\n    series: [351, 246, 144, 83],\r\n    labels: ['Devices', 'Watches', 'Bags', 'Shoes'],\r\n    \r\n}\r\nnew ApexCharts(document.querySelector(\"#categories-chart\"), categoriesChartOption).render();\r\n\r\nconst newDate = new Date()\r\nconst formattedDate = formatDate(newDate);\r\nconst divElement = document.querySelector('#date-query-input');\r\ndivElement.setAttribute('value', formattedDate);\r\n\r\nfunction formatDate(date) {\r\n    const year = date.getFullYear();\r\n    const month = String(date.getMonth() + 1).padStart(2, '0');\r\n    const day = String(date.getDate()).padStart(2, '0');\r\n    return `${month}/${day}/${year}`;\r\n}\n\n//# sourceURL=webpack://elstar/./src/es/pages/sales-dashboard.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/es/pages/sales-dashboard.js");
/******/ 	
/******/ })()
;